-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 25, 2020 at 04:42 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `fees`
--

CREATE TABLE `fees` (
  `Student_Fees` float NOT NULL,
  `Scholar_No` varchar(40) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `uname` varchar(20) DEFAULT NULL,
  `pwd` varchar(20) NOT NULL,
  `Acc_Type` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`uname`, `pwd`, `Acc_Type`) VALUES
('Neeraj', 'À£eî^^lÍS>¹Ÿ', 'Regular'),
('Aditya', 'ë+TVhcYžz6ÉSÆ²Äú', 'Regular'),
('Himank', 'E“Ô#¨á\"ó»l ä×ÞÕÒ', 'Regular'),
('Koustubh', 'ôFr÷pU¢<6¶ozþ', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `S_Name` varchar(40) DEFAULT NULL,
  `Fathers_Name` varchar(40) DEFAULT NULL,
  `Mothers_Name` varchar(40) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `E_Mail` varchar(40) DEFAULT NULL,
  `Mobile_No` varchar(40) DEFAULT NULL,
  `Gender` varchar(40) DEFAULT NULL,
  `Address` varchar(70) DEFAULT NULL,
  `DOR` date DEFAULT NULL,
  `State` varchar(40) DEFAULT NULL,
  `City` varchar(40) DEFAULT NULL,
  `Pincode` varchar(40) DEFAULT NULL,
  `Country` varchar(40) DEFAULT 'India',
  `Scholar_No` varchar(40) NOT NULL,
  `ApplyingFor` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student1`
--

CREATE TABLE `student1` (
  `Tenth_board` varchar(40) DEFAULT NULL,
  `Tenth_school` varchar(40) DEFAULT NULL,
  `Tenth_percentage` float DEFAULT NULL,
  `Tenth_passing` varchar(40) DEFAULT NULL,
  `Twelth_board` varchar(40) DEFAULT NULL,
  `Twelth_school` varchar(40) DEFAULT NULL,
  `Twelth_percentage` float DEFAULT NULL,
  `Twelth_passing` varchar(40) DEFAULT NULL,
  `Course` varchar(40) DEFAULT NULL,
  `Branch` varchar(40) DEFAULT NULL,
  `Scholar_No` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student2`
--

CREATE TABLE `student2` (
  `TFW` varchar(40) DEFAULT NULL,
  `Tenth_Marksheet` varchar(40) DEFAULT NULL,
  `Twelth_Marksheet` varchar(40) DEFAULT NULL,
  `TC` varchar(40) DEFAULT NULL,
  `Domicile` varchar(40) DEFAULT NULL,
  `Scholar_No` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student3`
--

CREATE TABLE `student3` (
  `Tenth_board` varchar(40) DEFAULT NULL,
  `Tenth_school` varchar(40) DEFAULT NULL,
  `Tenth_percentage` float DEFAULT NULL,
  `Tenth_passing` varchar(40) DEFAULT NULL,
  `Twelth_board` varchar(40) DEFAULT NULL,
  `Twelth_school` varchar(40) DEFAULT NULL,
  `Twelth_percentage` float DEFAULT NULL,
  `Twelth_passing` varchar(40) DEFAULT NULL,
  `college` varchar(40) DEFAULT NULL,
  `college_percent` float DEFAULT NULL,
  `college_passing` varchar(40) DEFAULT NULL,
  `course` varchar(40) DEFAULT NULL,
  `Branch` varchar(40) DEFAULT NULL,
  `Scholar_No` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student4`
--

CREATE TABLE `student4` (
  `TFW` varchar(40) DEFAULT NULL,
  `Tenth_Marksheet` varchar(40) DEFAULT NULL,
  `Twelth_Marksheet` varchar(40) DEFAULT NULL,
  `TC` varchar(40) DEFAULT NULL,
  `Domicile` varchar(40) DEFAULT NULL,
  `College_Degree` varchar(40) DEFAULT NULL,
  `Scholar_No` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fees`
--
ALTER TABLE `fees`
  ADD KEY `Scholar_No` (`Scholar_No`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`pwd`),
  ADD UNIQUE KEY `pwd` (`pwd`),
  ADD UNIQUE KEY `uname` (`uname`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`Scholar_No`),
  ADD UNIQUE KEY `Scholar_No` (`Scholar_No`),
  ADD UNIQUE KEY `Mobile_No` (`Mobile_No`);

--
-- Indexes for table `student1`
--
ALTER TABLE `student1`
  ADD UNIQUE KEY `Scholar_No` (`Scholar_No`);

--
-- Indexes for table `student2`
--
ALTER TABLE `student2`
  ADD UNIQUE KEY `Scholar_No` (`Scholar_No`);

--
-- Indexes for table `student3`
--
ALTER TABLE `student3`
  ADD UNIQUE KEY `Scholar_No` (`Scholar_No`);

--
-- Indexes for table `student4`
--
ALTER TABLE `student4`
  ADD UNIQUE KEY `Scholar_No` (`Scholar_No`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `fees`
--
ALTER TABLE `fees`
  ADD CONSTRAINT `fees_ibfk_1` FOREIGN KEY (`Scholar_No`) REFERENCES `student` (`Scholar_No`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`Scholar_No`) REFERENCES `student` (`Scholar_No`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student1`
--
ALTER TABLE `student1`
  ADD CONSTRAINT `student1_ibfk_1` FOREIGN KEY (`Scholar_No`) REFERENCES `student` (`Scholar_No`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student2`
--
ALTER TABLE `student2`
  ADD CONSTRAINT `student2_ibfk_1` FOREIGN KEY (`Scholar_No`) REFERENCES `student` (`Scholar_No`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student3`
--
ALTER TABLE `student3`
  ADD CONSTRAINT `student3_ibfk_1` FOREIGN KEY (`Scholar_No`) REFERENCES `student` (`Scholar_No`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student4`
--
ALTER TABLE `student4`
  ADD CONSTRAINT `student4_ibfk_1` FOREIGN KEY (`Scholar_No`) REFERENCES `student` (`Scholar_No`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
